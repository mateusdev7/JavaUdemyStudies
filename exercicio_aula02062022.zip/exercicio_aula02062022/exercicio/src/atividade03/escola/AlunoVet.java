package atividade03.escola;

public class AlunoVet {
    private Aluno[] alunoVet;
    private int quantVetor;

    public AlunoVet(int tamanho){
        this.alunoVet = new Aluno[tamanho];
        this.quantVetor = 0;
    }

    public Aluno getAlunoVet(int indice) {
        return this.alunoVet[indice];
    }

    public void setAlunoVet(int indice, Aluno aluno) {
        this.alunoVet[indice] = aluno;
    }

    public int getQuantVetor() {
        return quantVetor;
    }

    public void setQuantVetor(int quantVetor) {
        this.quantVetor = quantVetor;
    }

    public String toString() {
        String resposta = "";
        for(int i = 0; i < this.quantVetor; i++) {
            resposta += (i+1) + "\n" + this.alunoVet[i].toString();
        }
        return resposta;
    }

    public boolean cadastrarAluno(Aluno aluno) {
        if(this.quantVetor == this.alunoVet.length) {
            return false;
        }else {
            this.alunoVet[this.quantVetor] = aluno;
            this.quantVetor++;
            return true;
        }
    }

    public String consultarAlunos(double nota) {
        String nomes = "";
        if(alunoVet.length == 0) {
            nomes = "Não possuem alunos para serem consultados";
        }else {
            for (int i = 0; i < alunoVet.length; i++) {
                if (alunoVet[i].getNota1() < nota || alunoVet[i].getNota2() < nota) {
                    nomes += (alunoVet[i].getNomeDoAluno()) + ((i < alunoVet.length) ? " - " : "");
                }
                if(nomes.isEmpty()){
                    return "Não existem alunos com nota menor do que " + nota;
                }
            }
        }
        return nomes;
    }

    public String mediaAritmeticaENomeDoAluno(){
        if(this.quantVetor == 0) {
            return "Não existem alunos para calcular a média";
        }else {
            double media = 0.0;
            String nome = "";
            for(int i = 0; i < alunoVet.length; i++) {
                media = (alunoVet[i].getNota1() + alunoVet[i].getNota2()) / 2;
                nome += alunoVet[i].getNomeDoAluno();
            }
            return "Aluno" + nome + "\nMedia: " + media;
        }
    }
}
